Thank you for downloading Earth Pro Theme.

To Install Earth ProTheme, Put the "earth-pro" directory in your wp-content/themes directory and Activate the Theme from Wordpress Admin Panel.

If you want to build a blog, use the Template Type as "Blog Page" from the Page Attributes Section within the Add new Page section. The blog would come up in the page you created.


/*  Base Theme 
/* ------------------------------------ */ 
Underscores (_s) - Base Theme 
URL: http://underscores.me/ 
License: GNU GPL 
Copyright: Automattic, automattic.com 



License for javascripts:
-------------------------
1. customizer.js
License: Distributed under the terms of the GPL.


2. navigation.js
License: Distributed under the terms of the GPL.


3. skip-link-focus-fix.js
License: Distributed under the terms of the GPL.
